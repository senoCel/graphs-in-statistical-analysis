import requests
import csv
import webbrowser as wb

wb.open('RMarkdown_Anscombe_Graphs.pdf')

with open("summary.txt", "r") as file:
    content = file.read()
    print(content)

with open('Dataset_x_y_pairs.csv', mode='r') as file:
        csvFile = csv.reader(file)
        for lines in csvFile:
            print(lines)







