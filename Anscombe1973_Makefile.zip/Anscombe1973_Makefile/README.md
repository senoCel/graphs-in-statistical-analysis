**How to execute our Makefile**
1. Download the ZIP file from https://github.com/senoCel/graphs-in-statistical-analysis.
2. Unzip it, preferably in its own folder. The Makefile is in the folder "Graphs".
3. Open a terminal and navigate to the place where you unzipped the folder. Alternatively, you can click on the folder and chose "Open in terminal" or copy the path to the
   folder into the terminal.
5. Type "make run".

